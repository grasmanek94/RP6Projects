/*
 * led_value_updater_test.h
 *
 *  Created on: 22 nov. 2012
 *      Author: ben
 */

#ifndef LEVEL_CHECK_TEST_H_
#define LEVEL_CHECK_TEST_H_

void level_check_run_testcases(void);

#endif /* LED_VALUE_UPDATER_TEST_H_ */
