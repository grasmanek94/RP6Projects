#ifndef LED_VALUE_UPDATER_TEST_H_
#define LED_VALUE_UPDATER_TEST_H_

void led_values_updater_run_testcases(void);

#endif /* LED_VALUE_UPDATER_TEST_H_ */