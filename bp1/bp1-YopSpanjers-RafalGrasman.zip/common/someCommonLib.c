int someCommonFunction()
{
	return 1;
}