#ifndef someCommonLib_HEADER
#define someCommonLib_HEADER
int someCommonFunction();
#endif