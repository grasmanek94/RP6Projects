#ifndef base_HEADER
#define base_HEADER
void setup(void);
void loop(void);
#endif