#ifndef control_HEADER
#define control_HEADER
void setup(void);
void loop(void);
#endif